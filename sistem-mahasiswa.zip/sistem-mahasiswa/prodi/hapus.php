<?php
session_start(); if(!isset($_SESSION['login'])){header("Location: ../auth/login.php");exit;} require_once "../config/database.php"; require_once "../config/activity.php";
$id=(int)($_GET['id']??0);
try { $s=$conn->prepare("DELETE FROM prodi WHERE id=?");$s->bind_param("i",$id);$s->execute(); } catch(Throwable $e) {}
header("Location: index.php"); exit;
?>
