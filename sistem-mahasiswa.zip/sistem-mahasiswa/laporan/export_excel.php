<?php
session_start();if(!isset($_SESSION['login']))exit;
require_once "../config/database.php";
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="data-mahasiswa.csv"');
echo "\xEF\xBB\xBF";
$out=fopen('php://output','w');
fputcsv($out,['No','NPM','Nama','Jenis Kelamin','Program Studi','Angkatan']);
$q=$conn->query("SELECT m.*,p.nama_prodi FROM mahasiswa m LEFT JOIN prodi p ON m.prodi_id=p.id ORDER BY m.nama");
$i=1;while($r=$q->fetch_assoc())fputcsv($out,[$i++,$r['npm'],$r['nama'],$r['jenis_kelamin'],$r['nama_prodi'],$r['angkatan']]);
fclose($out);
