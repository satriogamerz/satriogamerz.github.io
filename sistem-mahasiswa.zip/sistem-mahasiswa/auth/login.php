<?php
session_start();
require_once "../config/database.php";
if (isset($_SESSION['login'])) { header("Location: ../index.php"); exit; }

$error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST['username'] ?? '');
    $password = md5($_POST['password'] ?? '');

    $stmt = $conn->prepare("SELECT id, username, nama_lengkap FROM users WHERE username=? AND password=?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $u = stmt_first($stmt);

    if ($u) {
        $_SESSION['login'] = true;
        $_SESSION['user_id'] = $u['id'];
        $_SESSION['username'] = $u['username'];
        $_SESSION['nama_lengkap'] = $u['nama_lengkap'];
        header("Location: ../index.php"); exit;
    }
    $error = "Username atau password salah.";
}
?>
<!doctype html>
<html lang="id"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login - SIM Mahasiswa</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>body{min-height:100vh;background:linear-gradient(135deg,#198754,#0d6efd);display:flex;align-items:center;justify-content:center}.card{width:400px;border:0;border-radius:20px;overflow:hidden}.head{background:#198754;color:#fff;text-align:center;padding:30px}.body{padding:30px}</style>
</head><body><div class="card shadow-lg">
<div class="head"><h3>SIM MAHASISWA</h3><div>Universitas Muhammadiyah Bengkulu</div></div>
<div class="body"><h5 class="text-center mb-4">Login Administrator</h5>
<?php if($error): ?><div class="alert alert-danger"><?=htmlspecialchars($error)?></div><?php endif; ?>
<form method="post">
<label class="form-label">Username</label><input name="username" class="form-control mb-3" required>
<label class="form-label">Password</label><input type="password" name="password" class="form-control mb-3" required>
<button class="btn btn-success w-100 py-2">LOGIN</button>
</form><div class="text-center text-muted mt-4 small">Teknik Informatika - UMB</div></div></div></body></html>
