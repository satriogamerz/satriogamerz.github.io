<?php
session_start();
if (!isset($_SESSION['login'])) { header("Location: ../auth/login.php"); exit; }
require_once "../config/database.php";
$cari = trim($_GET['cari'] ?? '');
$prodi = (int)($_GET['prodi'] ?? 0);
$where=[]; $params=[]; $types='';
if ($cari!=='') { $where[]="(m.npm LIKE ? OR m.nama LIKE ? OR m.email LIKE ?)"; $x="%$cari%"; $params=[$x,$x,$x]; $types.="sss"; }
if ($prodi>0) { $where[]="m.prodi_id=?"; $params[]=$prodi; $types.="i"; }
$sql="SELECT m.*,p.nama_prodi FROM mahasiswa m JOIN prodi p ON m.prodi_id=p.id";
if($where) $sql.=" WHERE ".implode(" AND ",$where);
$sql.=" ORDER BY m.id DESC";
$stmt=$conn->prepare($sql); if($params) $stmt->bind_param($types,...$params); $stmt->execute(); $data=stmt_rows($stmt);
$prodis=$conn->query("SELECT * FROM prodi ORDER BY nama_prodi");
?>
<!doctype html><html lang="id"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Data Mahasiswa</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>body{background:#f4f6f9}.sidebar{width:250px;height:100vh;position:fixed;background:#198754;color:#fff;padding-top:20px}.brand{text-align:center;padding:15px;font-weight:bold;font-size:21px;border-bottom:1px solid #ffffff33}.menu{padding:20px 15px}.sidebar a{display:block;color:#fff;text-decoration:none;padding:13px 15px;border-radius:8px;margin-bottom:7px}.sidebar a:hover,.sidebar a.active{background:#ffffff33}.main{margin-left:250px;padding:25px}.card{border:0;border-radius:15px}@media(max-width:768px){.sidebar{width:70px}.brand{font-size:0}.brand:after{content:"SIM";font-size:18px}.sidebar a span{display:none}.main{margin-left:70px}}</style></head><body>
<div class="sidebar"><div class="brand">SIM MAHASISWA</div><div class="menu"><a href="../index.php"><i class="bi bi-speedometer2"></i><span> Dashboard</span></a><a class="active" href="index.php"><i class="bi bi-people"></i><span> Data Mahasiswa</span></a><a href="../prodi/index.php"><i class="bi bi-building"></i><span> Program Studi</span></a><a href="../aktivitas.php"><i class="bi bi-clock-history"></i><span> Aktivitas</span></a><a href="../auth/logout.php"><i class="bi bi-box-arrow-right"></i><span> Logout</span></a></div></div>
<div class="main"><div class="d-flex justify-content-between align-items-center mb-4"><div><h3>Data Mahasiswa</h3><p class="text-muted mb-0">Kelola data mahasiswa</p></div><a href="tambah.php" class="btn btn-success"><i class="bi bi-plus-circle"></i> Tambah Mahasiswa</a></div>
<div class="card shadow-sm p-3 mb-4"><form class="row g-2"><div class="col-md-5"><input name="cari" value="<?=htmlspecialchars($cari)?>" class="form-control" placeholder="Cari NPM, nama, atau email..."></div><div class="col-md-4"><select name="prodi" class="form-select"><option value="0">Semua Program Studi</option><?php while($p=$prodis->fetch_assoc()): ?><option value="<?=$p['id']?>" <?=$prodi==$p['id']?'selected':''?>><?=htmlspecialchars($p['nama_prodi'])?></option><?php endwhile; ?></select></div><div class="col-md-3"><button class="btn btn-primary">Cari / Filter</button> <a href="index.php" class="btn btn-secondary">Reset</a></div></form></div>
<div class="card shadow-sm p-3"><div class="table-responsive"><table class="table table-hover align-middle"><thead><tr><th>No</th><th>NPM</th><th>Nama</th><th>JK</th><th>Prodi</th><th>Angkatan</th><th>Aksi</th></tr></thead><tbody>
<?php $no=1; foreach($data as $m): ?><tr><td><?=$no++?></td><td><?=htmlspecialchars($m['npm'])?></td><td><?=htmlspecialchars($m['nama'])?></td><td><?=htmlspecialchars($m['jenis_kelamin'])?></td><td><?=htmlspecialchars($m['nama_prodi'])?></td><td><?=$m['angkatan']?></td><td><a class="btn btn-sm btn-warning" href="edit.php?id=<?=$m['id']?>"><i class="bi bi-pencil"></i></a> <a class="btn btn-sm btn-danger" href="hapus.php?id=<?=$m['id']?>" onclick="return confirm('Hapus data ini?')"><i class="bi bi-trash"></i></a></td></tr>
<?php endforeach; if(count($data)===0): ?><tr><td colspan="7" class="text-center text-muted">Data tidak ditemukan.</td></tr><?php endif; ?>
</tbody></table></div></div></div></body></html>
