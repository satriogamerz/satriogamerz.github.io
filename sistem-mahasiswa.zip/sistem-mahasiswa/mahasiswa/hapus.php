<?php
session_start(); if(!isset($_SESSION['login'])){header("Location: ../auth/login.php");exit;} require_once "../config/database.php"; require_once "../config/activity.php";
$id=(int)($_GET['id']??0); $stmt=$conn->prepare("DELETE FROM mahasiswa WHERE id=?");$stmt->bind_param("i",$id);$stmt->execute();header("Location: index.php");exit;
?>
