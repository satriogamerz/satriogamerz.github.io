<?php
session_start(); if(!isset($_SESSION['login'])){header("Location: ../auth/login.php");exit;} require_once "../config/database.php"; require_once "../config/activity.php";
$error="";
if($_SERVER['REQUEST_METHOD']==='POST'){
$npm=trim($_POST['npm']);$nama=trim($_POST['nama']);$jk=$_POST['jenis_kelamin'];$tempat=trim($_POST['tempat_lahir']);$tgl=$_POST['tanggal_lahir']?:null;$alamat=trim($_POST['alamat']);$hp=trim($_POST['no_hp']);$email=trim($_POST['email']);$prodi=(int)$_POST['prodi_id'];$angkatan=(int)$_POST['angkatan'];
$stmt=$conn->prepare("INSERT INTO mahasiswa(npm,nama,jenis_kelamin,tempat_lahir,tanggal_lahir,alamat,no_hp,email,prodi_id,angkatan) VALUES(?,?,?,?,?,?,?,?,?,?)");
$stmt->bind_param("ssssssssii",$npm,$nama,$jk,$tempat,$tgl,$alamat,$hp,$email,$prodi,$angkatan);
if($stmt->execute()){header("Location: index.php");exit;} $error="Gagal menyimpan. Pastikan NPM belum digunakan.";
}
$prodis=$conn->query("SELECT * FROM prodi ORDER BY nama_prodi");
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Tambah Mahasiswa</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"></head><body class="bg-light"><div class="container py-4"><div class="card shadow-sm p-4"><h3>Tambah Mahasiswa</h3><hr><?php if($error): ?><div class="alert alert-danger"><?=$error?></div><?php endif; ?><form method="post"><div class="row g-3">
<div class="col-md-6"><label class="form-label">NPM</label><input name="npm" class="form-control" required></div><div class="col-md-6"><label class="form-label">Nama</label><input name="nama" class="form-control" required></div>
<div class="col-md-6"><label class="form-label">Jenis Kelamin</label><select name="jenis_kelamin" class="form-select" required><option value="">Pilih</option><option>Laki-laki</option><option>Perempuan</option></select></div><div class="col-md-6"><label class="form-label">Program Studi</label><select name="prodi_id" class="form-select" required><option value="">Pilih</option><?php while($p=$prodis->fetch_assoc()): ?><option value="<?=$p['id']?>"><?=htmlspecialchars($p['nama_prodi'])?></option><?php endwhile; ?></select></div>
<div class="col-md-6"><label class="form-label">Tempat Lahir</label><input name="tempat_lahir" class="form-control"></div><div class="col-md-6"><label class="form-label">Tanggal Lahir</label><input type="date" name="tanggal_lahir" class="form-control"></div>
<div class="col-md-6"><label class="form-label">No. HP</label><input name="no_hp" class="form-control"></div><div class="col-md-6"><label class="form-label">Email</label><input type="email" name="email" class="form-control"></div>
<div class="col-md-6"><label class="form-label">Angkatan</label><input type="number" name="angkatan" value="<?=date('Y')?>" class="form-control" required></div><div class="col-12"><label class="form-label">Alamat</label><textarea name="alamat" class="form-control" rows="3"></textarea></div>
</div><div class="mt-4"><button class="btn btn-success">Simpan</button> <a href="index.php" class="btn btn-secondary">Kembali</a></div></form></div></div></body></html>
