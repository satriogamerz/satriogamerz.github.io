<?php
/*
 * Database loader compatible with XAMPP and shared hosting.
 * On hosting, fill the database credentials once through /setup.php.
 */
$configFile = __DIR__ . '/db_config.php';
$isLocal = isset($_SERVER['HTTP_HOST']) && (strpos($_SERVER['HTTP_HOST'], 'localhost') !== false || strpos($_SERVER['HTTP_HOST'], '127.0.0.1') !== false);

if (file_exists($configFile)) {
    require $configFile;
} elseif ($isLocal) {
    $host = 'localhost'; $user = 'root'; $pass = ''; $db = 'sistem_mahasiswa';
} else {
    http_response_code(503);
    $script = $_SERVER['SCRIPT_NAME'] ?? '/';
    $dir = trim(dirname($script), '/');
    $depth = $dir === '' ? 0 : substr_count($dir, '/') + 1;
    $link = str_repeat('../', $depth) . 'setup.php';
    echo '<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Setup Database</title><style>body{font-family:Arial,sans-serif;background:#f4f6f9;display:flex;align-items:center;justify-content:center;min-height:100vh}.box{background:#fff;padding:32px;border-radius:16px;max-width:620px;box-shadow:0 10px 30px #0001}a{display:inline-block;background:#198754;color:#fff;padding:12px 18px;border-radius:8px;text-decoration:none}</style></head><body><div class="box"><h2>Database belum dikonfigurasi</h2><p>Hosting sudah menjalankan PHP, tetapi koneksi database belum diatur. Klik tombol di bawah untuk melakukan setup.</p><a href="'.htmlspecialchars($link, ENT_QUOTES, 'UTF-8').'">Setup Database</a></div></body></html>';
    exit;
}

try {
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $conn = new mysqli($host, $user, $pass, $db);
    $conn->set_charset('utf8mb4');
} catch (Throwable $e) {
    http_response_code(503);
    $script = $_SERVER['SCRIPT_NAME'] ?? '/';
    $dir = trim(dirname($script), '/');
    $depth = $dir === '' ? 0 : substr_count($dir, '/') + 1;
    $link = str_repeat('../', $depth) . 'setup.php';
    echo '<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Koneksi Database Gagal</title><style>body{font-family:Arial,sans-serif;background:#f4f6f9;display:flex;align-items:center;justify-content:center;min-height:100vh}.box{background:#fff;padding:32px;border-radius:16px;max-width:680px;box-shadow:0 10px 30px #0001}a{display:inline-block;background:#198754;color:#fff;padding:12px 18px;border-radius:8px;text-decoration:none}.err{background:#fff3cd;padding:12px;border-radius:8px}</style></head><body><div class="box"><h2>Koneksi database gagal</h2><p>Periksa host, username, password, dan nama database hosting.</p><div class="err">'.htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8').'</div><br><a href="'.htmlspecialchars($link, ENT_QUOTES, 'UTF-8').'">Buka Setup Database</a></div></body></html>';
    exit;
}

/* Portable replacement for mysqli_stmt::get_result() when mysqlnd is unavailable. */
function stmt_rows($stmt) {
    if (function_exists('mysqli_stmt_get_result')) {
        $result = mysqli_stmt_get_result($stmt);
        $rows = [];
        while ($row = $result->fetch_assoc()) $rows[] = $row;
        return $rows;
    }
    $meta = $stmt->result_metadata();
    if (!$meta) return [];
    $fields = $meta->fetch_fields();
    $row = []; $refs = [];
    foreach ($fields as $field) { $row[$field->name] = null; $refs[] = &$row[$field->name]; }
    call_user_func_array([$stmt, 'bind_result'], $refs);
    $rows = [];
    while ($stmt->fetch()) {
        $copy = [];
        foreach ($row as $k => $v) $copy[$k] = $v;
        $rows[] = $copy;
    }
    return $rows;
}
function stmt_first($stmt) { $rows = stmt_rows($stmt); return $rows ? $rows[0] : null; }
?>
