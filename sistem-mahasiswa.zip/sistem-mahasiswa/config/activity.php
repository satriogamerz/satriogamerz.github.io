<?php
function log_activity($conn,$activity){
    $conn->query("CREATE TABLE IF NOT EXISTS aktivitas (
      id INT AUTO_INCREMENT PRIMARY KEY,
      nama_pengguna VARCHAR(100) NOT NULL,
      aktivitas VARCHAR(255) NOT NULL,
      waktu DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");
    $activity=$conn->real_escape_string($activity);
    $user=isset($_SESSION['nama_lengkap'])?$conn->real_escape_string($_SESSION['nama_lengkap']):'Admin';
    $conn->query("INSERT INTO aktivitas (nama_pengguna,aktivitas) VALUES ('$user','$activity')");
}
?>